shell Basics Readme
