shell permissions
